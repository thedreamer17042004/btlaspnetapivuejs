<template>
    <breadcrumb first="Home" second="Login"></breadcrumb>
    <!-- Li's Breadcrumb Area End Here -->
    <!-- Begin Login Content Area -->
    <div class="page-section mb-60">
        <div class="container">
            <div class="row" style="justify-content:center;margin-top:5px">
                <div class="col-sm-12 col-md-12 col-xs-12 col-lg-6 mb-30">
                   <form-login></form-login>
                </div>

            </div>
        </div>
    </div>
</template>


<script >
import FormLogin from '@/components/web/form/login/Login.vue'
import Breadcrumb from '@/components/web/breadcrumb/Breadcrumb.vue'

export default {
    name: 'Login',
    components: {
        FormLogin,
        Breadcrumb
    }
}

</script>

<style scoped></style>