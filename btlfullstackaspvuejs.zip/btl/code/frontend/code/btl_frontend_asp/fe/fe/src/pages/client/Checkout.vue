<template>
    <user-layout>
       <breadcrumb first="Home" second="Checkout"></breadcrumb>
        <!-- Li's Breadcrumb Area End Here -->
        <!--Checkout Area Strat-->
        <div class="checkout-area pt-60 pb-30">
            <div class="container">
               
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <form-checkout></form-checkout>
                    <!-- form -->
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="your-order">
                            <h3>Your order</h3>
                            <div class="your-order-table table-responsive">
                               <!-- table -->
                                <table-checkout></table-checkout>
                            </div>
                            <div class="payment-method">
                                <div class="payment-accordion">
                                  
                                    <div class="order-button-payment">
                                        <input value="Place order" type="submit">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </user-layout>
</template>


<script>
import UserLayout from '@/layouts/web/UserLayout.vue';
import Breadcrumb from '@/components/web/breadcrumb/Breadcrumb.vue';
import FormCheckout from '@/components/web/form/checkout/FormCheckout.vue';
import TableCheckout from '@/components/web/table/checkout/TableCheckout.vue';
export default {
    name: 'Checkout',
    components: {
        UserLayout,
        Breadcrumb,
        FormCheckout,
        TableCheckout
    }
}

</script>

<style scoped></style>