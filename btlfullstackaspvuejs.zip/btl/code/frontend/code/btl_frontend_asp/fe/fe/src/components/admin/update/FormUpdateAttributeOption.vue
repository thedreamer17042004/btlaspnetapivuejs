<template>
    <form method="post" @submit.prevent="submitForm" >
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="Name" class="form-label ">
                                OptionName<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="OptionName"
                                    v-model="formData.OptionName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.name" class="text-danger">{{ errors.name }}</span>
                        </div>
                        <div class="col-12" style="padding-left: 0px;">
                            <label asp-for="AttributeId" class="form-label mt-1">
                                Attribute<span style="color:red">(*)</span>
                            </label>
                            <select v-model="formData.AttributeId" id="AttributeId" class="form-select mb-3"
                                aria-label="Default select example">
                                <option value="">Select your attribute</option>
                                <option v-for="item in data" :key="item.attributeId" :value="item.id ">{{ item.attributeName }}</option>
                               
                            </select>
                            <span v-if="errors.attributeId" class="text-danger">{{ errors.attributeId }}</span>
                        </div>
                        </div>
                </div>
            </div>

         

        </div>


     
        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapGetters, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'
import { AttributeOptionService } from '@/service/attributeOption';

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'OptionName': '',
                'AttributeId': '',
            },
          
        }
    },
    methods: {
        ...mapActions('attributeoption', ['update']),
        ...mapActions('attribute', ['fetchData']),
        getData() {
          const data=  {
                'PageNumber':1,
                'PageSize':100,
                'Keyword':'',
                'Status': ''
            }
            this.fetchData(data);
        },
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.OptionName) {
                this.errors.name = 'OptionName is required';
                isValid = false;
            }

          
             if (!this.formData.AttributeId){
                this.errors.attributeId = 'AttributeId is required';
                isValid = false;
            }

            return isValid;
        },
      
         submitForm() {
            if(this.validate()){

                const formData = {
                    'OptionName': this.formData.OptionName,
                    'AttributeId': this.formData.AttributeId,
                }
           
                // console.log(this.$route.params.id + form.CategoryName)
                this.update({id:this.$route.params.id,formData});
            }
        },
        
        async fetchCategoryDetails(id) {
            var response =  await  AttributeOptionService.findById(id);
            this.mapFormData(response.data);
        },
        mapFormData(data) {
            this.formData = {
                OptionName: data.optionName || '',
                AttributeId: data.attributeId || '',
                
            };
        }
    },
    computed: {
        ...mapState('attributeoption',[
        'success'
      ]),
      ...mapGetters('attribute', ['data']),
    },
    watch: {
        'success':  function() {
          if(this.success==true){
            const {showSuccess, showError} = useNotification();
            showSuccess();
            this.$router.push({name:'attributeoption'})
          }
        }
       
    },
    mounted() {
        const id = this.$route.params.id;
        this.fetchCategoryDetails(id);
    },
    created() {
        this.getData();
    }
}
</script>

<style scoped></style>