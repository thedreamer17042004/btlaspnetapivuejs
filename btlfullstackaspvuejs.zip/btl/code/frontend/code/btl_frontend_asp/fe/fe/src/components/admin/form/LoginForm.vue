<template>

    <form @submit.prevent="submitForm"  method="post">
    
    <div class="mb-3">
        <label for="username" class="form-label">Email</label>
        <input type="text" v-model="formData.Email" class="form-control" id="username" name="Email" value="" placeholder="Enter email">
        <span @v-if="errors.email" class="text-danger">{{ errors.email }}</span>
    </div>
    
    <div class="mb-3">
      
        <label class="form-label" for="password-input">Password</label>
        <div class="position-relative auth-pass-inputgroup mb-3">
            <input type="password" class="form-control pe-5 password-input" v-model="formData.Password" name="Password" placeholder="Enter password" value="" id="password-input">
            <span @v-if="errors.password" class="text-danger">{{ errors.password }}</span>
        </div>
    </div>
    
    <div class="mt-4">
        <button class="btn btn-success w-100" type="submit">Sign In</button>
    </div>
    
    </form>
    </template>
    
    <script>
    import { mapActions, mapGetters, mapState } from 'vuex';
    import { useNotification } from '../notification/Notification';
    
    
    export default{
        name: 'Login admin',
        data() {
            return {
                errors:{},
                formData: {
                    'Email': '',
                    'Password': ''
                }
            }
    
        },
        methods:{
            ...mapActions('auth', ['login']),
            validate() {
                this.errors = {};
                let isValid = true;
    
                if (!this.formData.Email) {
                    this.errors.email = 'Email  is required';
                    isValid = false;
                }
    
               
                 if (!this.formData.Password){
                    this.errors.password = 'Passsword  is required';
                    isValid = false;
                }
    
                return isValid;
            },
            async submitForm() {
                if(this.validate()){
                    this.login(this.formData);
                    
                }
            },
        },
        computed: {
            ...mapGetters('auth', ['success'])
        },
        watch:{
        'success': function() {
            const {showSuccess, showError} = useNotification();
            if(this.success==true){
                showSuccess();
                this.$router.push({name:'Dashboard'})   
            }
        }
    }
    }
    </script>
    
    <style scoped></style>