<template>

    <form method="post" @submit.prevent="submitForm" enctype="multipart/form-data">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="Username" class="form-label ">
                                Product Name<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="Username"
                                    v-model="formData.ProductName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.productname" class="text-danger">{{ errors.productname }}</span>
                        </div>
                        <div class="mt3">
                            <label asp-for="Email" class="form-label mt-1">
                                Price<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="number" class="form-control form-control-icon" value="" id="Email"
                                    v-model="formData.Price" placeholder="Enter price">
                                <i class="ri-mail-unread-line"></i>
                            </div>
                            <span v-if="errors.price" class="text-danger">{{ errors.price }}</span>
                        </div>
                        <div>
                            <label asp-for="SalePrice" class="form-label mt-1">
                                Sale price
                            </label>
                            <div class="form-icon right">
                                <input type="number" class="form-control form-control-icon" value="0" id="SalePrice"
                                    v-model="formData.SalePrice" placeholder="">
                                <i class="ri-lock-2-line"></i>
                            </div>
                            <span v-if="errors.saleprice" class="text-danger">{{ errors.saleprice }}</span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Other infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label mt-1">
                                    Active
                                </label>
                                <select v-model="formData.Active" id="Gender" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option selected value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>

                            </div>

                            <div class="col-12">
                                <label class="form-label mt-1">
                                    Category
                                </label>
                                <select v-model="formData.CategoryId" id="Gender" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option value="">Select category</option>
                                    <option v-for="item in data" :key="item.id" :value="item.id">{{ item.categoryName
                                        }}</option>
                                </select>
                                <span v-if="errors.categoryid" class="text-danger">{{ errors.categoryid }}</span>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>


        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Image and album</h4>
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="mt3">
                            <label for="iconrightInput" class="form-label mt-1">
                                Image
                            </label>
                            <div class="form-icon right">
                                <input type="file" name="Image" @change="handleFile" accept="image/*"
                                    class="form-control form-control-icon" id="Image">
                                <i class="mdi mdi-file-image-minus-outline"></i>
                            </div>
                        </div>
                        <div class="mt3">
                            <label for="iconrightInput" class="form-label mt-1">
                                Album
                            </label>
                            <div class="form-icon right">
                                <input type="file" @change="handleFileChange" multiple name="Album[]" accept="image/*"
                                    class="form-control form-control-icon" id="Album">
                                <i class="mdi mdi-file-image-minus-outline"></i>
                            </div>
                        </div>
                        <!-- Display selected images with remove and drag functionality -->
                        <div v-if="imagePreviews.length" class="image-container" @dragover.prevent @drop="handleDrop">
                            <div v-for="(image, index) in imagePreviews" :key="index" class="image-preview"
                                draggable="true" @dragstart="handleDragStart(index)" @dragover.prevent>
                                <img :src="image" alt="Image preview" width="100px" />
                                <i class="ri-chat-delete-line icon-check" @click="removeImage(index)"></i>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-6">
                <div class="card " id="form-container">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Attribute</h4>
                    </div>
                    <AttributeInput @update:forms="handleForm" />

                </div>
            </div>

            <!-- <div v-if="formAttribute.length > 0">
                <h2>Form Data:</h2>
                <ul>
                    <li v-for="(form, index) in formAttribute" :key="index">
                        <p>Form {{ index + 1 }}:</p>
                        <p>Attribute ID: {{ form.AttributeId }}</p>
                        <p>Option ID: {{ form.OptionId }}</p>
                     
                    </li>
                </ul>
            </div> -->

        </div>
        <div>

        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Description</h4>

                    </div><!-- end card header -->
                    <div class="card-body">
                        <!-- <div id="editor" ref="editor"></div> -->
                        <!-- <input type="hidden" id="Description" name="Description" v-model="formData.Description" /> -->
                        <textarea name="Description" style="height: 300px;" v-model="formData.Description"></textarea>
                    </div>

                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import { mapActions, mapGetters, mapState } from 'vuex'
import { useNotification } from '@/components/admin/notification/Notification.js'
import AttributeInput from '@/components/admin/AttributeInput.vue'
import attribute from '@/store/modules/attribute'

import { ref } from 'vue';
// import Quill from 'quill';

export default {
    name: 'Form create',
    data() {
        return {
            errors: {},
            file: null,
            albums: [],
            quill: null,
            formAttribute: [],
            formData: {
                'ProductName': '',
                'Price': '',
                'SalePrice': '0',
                'Active': '1',
                'Image': '',
                'ProductName': '',
                'CategoryId': '',
                'Album': '',
                'Attributes': '',
                'Description': ''
            },
        }
    },
    setup() {
        const imagePreviews = ref([]);
        const uploadedFiles = ref([]);
        const handleFileChange = (event) => {
            const files = event.target.files;
            imagePreviews.value = [];
            uploadedFiles.value = [];

            for (const file of files) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    imagePreviews.value.push(e.target.result);
                };
                reader.readAsDataURL(file); // Read the file as a data URL
                uploadedFiles.value.push(file)
                // this.addAlbum(file)
                // console.log(this.albums.length)
            }
        };

        const removeImage = (index) => {
            // Revoke the object URL to avoid memory leaks
            imagePreviews.value.splice(index, 1); // Remove image at the specified index
            uploadedFiles.value.splice(index, 1); // Remove image at the specified index
            // Remove from files
            //    this.removeAlbum(index)
        };


        return {
            imagePreviews,
            handleFileChange,
            removeImage,
            uploadedFiles
        };
    },
    methods: {
        ...mapActions('product', ['create']),
        // ...mapActions('attribute', ['fetchData']),
        ...mapActions('category', ['fetchData']),

        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.ProductName) {
                this.errors.productname = 'ProductName is required';
                isValid = false;
            }

            if (!this.formData.Price) {
                this.errors.price = 'Price is required';
                isValid = false;
            }

            if (!this.formData.CategoryId) {
                this.errors.categoryid = 'Categoryid is required';
                isValid = false;
            }

            return isValid;
        },
        handleForm(forms) {
            this.formAttribute = forms;
        },
        handleFile(event) {
            this.file = event.target.files[0];
        },

        async submitForm() {
            if (this.validate()) {
                var formData = new FormData();
                if (this.file) {
                    formData.append('Image', this.file)
                }
                formData.append('ProductName', this.formData.ProductName)
                formData.append('Price', this.formData.Price)
                formData.append('SalePrice', this.formData.SalePrice)
                formData.append('Active', this.formData.Active)
                formData.append('CategoryId', this.formData.CategoryId)
                formData.append('Album', this.formData.Album)
                formData.append('Description', this.formData.Description)

                formData.append('Attributes', JSON.stringify(this.formAttribute))

                this.uploadedFiles.forEach(file => {
                    formData.append('Album', file);
                });

                this.create(formData);
            }
        },
        getData() {
            const data = {
                'PageNumber': 1,
                'PageSize': 100,
                'Keyword': '',
                'Status': ''
            }
            this.fetchData(data);
            // this.fetchData(data);


        },
    },
    components: {
        AttributeInput
    },
    computed: {
        ...mapState('product', [
            'success'
        ]),
        ...mapGetters('product', [
            'success'
        ]),
        ...mapGetters('category', ['data']),

    },
    watch: {
        'success': function () {
            const { showSuccess, showError } = useNotification();
            if (this.success == true) {
                showSuccess();
                // this.$router.push({ name: 'product' })
            }
        }
    },
    created() {
        this.getData();
    },
    mounted() {
        // this.initializeQuill();
    },
}
</script>

<style scoped>
.image-container {
    display: flex;
    gap: 30px;
    padding: 10px;
    flex-wrap: wrap;
    justify-content: center;
}

.image-preview {
    border: 1px solid #e9e9d5;
    position: relative;
}

.icon-check {
    position: absolute;
    top: -9px;
    left: -14px;
    font-size: 20px;
    cursor: pointer;
}
</style>