<template>
    <!-- ========== App Menu ========== -->
    <div class="app-menu navbar-menu">
        <!-- LOGO -->
        <div class="navbar-brand-box">
            <!-- Dark Logo-->

            <a href="index.html" class="logo logo-dark">
                <span class="logo-sm">
                    <img src="@/assets/admin/images/logo-sm.png" alt="" height="22">
                </span>
                <span class="logo-lg">
                    <img src="@/assets/admin/images/logo-dark.png" alt="" height="17">
                </span>
            </a>
            <!-- Light Logo-->
            <a href="index.html" class="logo logo-light">
                <span class="logo-sm">
                    <img src="@/assets/admin/images/logo-sm.png" alt="" height="22">
                </span>
                <span class="logo-lg">
                    <img src="@/assets/admin/images/logo-light.png" alt="" height="17">
                </span>
            </a>
            <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                id="vertical-hover">
                <i class="ri-record-circle-line"></i>
            </button>
        </div>
        <div class="custom-scrollbar">
            <div class="container-fluid">

                <div id="two-column-menu">
                </div>

                <ul class="navbar-nav" id="navbar-nav">
                    <li class="menu-title"><span data-key="t-menu">Menu</span></li>

                    <li class="nav-item" v-for="(item, index) in filteredNavItems" :key="item.id">
                        <a @click="toggleDropdown(index)" class="nav-link menu-link" data-bs-toggle="collapse"
                            role="button" aria-expanded="false" aria-controls="sidebarPages">
                            <i :class="item.icon"></i> <span>{{ item.label }}</span>
                        </a>
                        <div class=" menu-dropdown" v-if="dropdownStates[index]">
                            <ul class="nav nav-sm flex-column">
                                <li class="nav-item" v-for="(subItem, subIndex) in item.subItems" :key="subIndex">
                                    <router-link :to="{name: subItem.href}" class="nav-link">{{ subItem.label }}</router-link>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>

        </div>

        <div class="sidebar-background"></div>
    </div>

    <!-- Left Sidebar End -->
    <!-- Vertical Overlay-->
    <div class="vertical-overlay"></div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue';
import { useStore } from 'vuex';
import { decodeToken, isTokenExpired, getUserRole, getUserId } from '@/utils/jwtUtils';
import auth from '@/store/modules/auth';

// Use Vuex store
const store = useStore();

const token = computed(() => store.state.auth.data);

const userRole = computed(() => getUserRole(token.value));


// Reactive state for nav items and dropdown states
const navItems = reactive([
  {
    id: 1,
    label: 'Account',
    icon: 'mdi mdi-sticker-text-outline',
    subItems: [
      { href: 'account', label: 'Danh sách' },
      { href: 'createaccount', label: 'Thêm mới' }
    ]
  },
  {
    id: 2,
    label: 'Category',
    icon: 'mdi mdi-cube-outline',
    subItems: [
      { href: 'category', label: 'Danh sách' },
      { href: 'createcategory', label: 'Thêm mới' }
    ]
  },
  {
    id: 3,
    label: 'Attribute',
    icon: 'mdi mdi-layers-triple-outline',
    subItems: [
      { href: 'attribute', label: 'Danh sách' },
      { href: 'createattribute', label: 'Thêm mới' }
    ]
  },
  {
    id: 4,
    label: 'Product',
    icon: 'mdi mdi-chart-donut',
    subItems: [
      { href: 'product', label: 'Danh sách' },
      { href: 'createproduct', label: 'Thêm mới' }
    ]
  },
  {
    id: 5,
    label: 'Order',
    icon: 'mdi mdi-map-marker-outline',
    subItems: [
      { href: '/admin/order', label: 'Danh sách' }
    ]
  }
]);

const dropdownStates = ref(Array(navItems.length).fill(false));

// Method to toggle dropdown state
const toggleDropdown = (index) => {
  dropdownStates.value[index] = !dropdownStates.value[index];
};

// Computed property to access Vuex state
const isShowSideBar = computed(() => store.state.settings.isShowSideBar);

const filteredNavItems = computed(() => {
  if (userRole.value === 'Admin') {
    return navItems;
  } else {
    // Filter out items or return only non-admin items
    return navItems.filter(item => item.id !== 1 && item.id !==2 && item.id !==4 && item.id !== 5); // Example: Hide "Account" menu for non-admin users
  }
});

</script>

<style scoped></style>