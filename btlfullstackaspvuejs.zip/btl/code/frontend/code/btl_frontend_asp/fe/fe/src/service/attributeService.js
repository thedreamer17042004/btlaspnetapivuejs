import axios from "axios";
import auth from "@/store/modules/auth";
export class AttributeService {
    /**
     ******************************
     * @API
     ******************************
     */
  
    static async getAll (data) {
      try {
        const response = await axios.post(`https://localhost:7038/api/attribute/search`, data, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async create (formData) {
      try {
       
        const response = await axios.post(`https://localhost:7038/api/attribute`, 
           formData
        , {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async findById (id) {
      try {
       
        const response = await axios.get(`https://localhost:7038/api/attribute/`+id, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async update (id, body) {
      try {
       console.log(body)
        const response = await axios.put(`https://localhost:7038/api/attribute/${id}`,body,
          {
            headers: {
              'Content-Type': 'application/json' ,
              'Authorization': `Bearer ${auth.state.data}`,
            }
          }
          );
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async delete (id) {
      try {
   
        const response = await axios.delete(`https://localhost:7038/api/attribute/${id}`,{
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }
  
   
  }
  