// services/storageService.js

const StorageService = {
    // Save data to localStorage or sessionStorage
    set(key, value, useSession = false) {
      const storage = useSession ? sessionStorage : localStorage;
      // const serializedValue = JSON.stringify(value);
      storage.setItem(key, serializedValue);
    },
  
    // Retrieve data from localStorage or sessionStorage
    get(key, useSession = false) {
      const storage = useSession ? sessionStorage : localStorage;
      const serializedValue = storage.getItem(key);
      try {
        // return JSON.parse(serializedValue);
        return serializedValue;
      } catch (e) {
        console.error('Failed to parse stored value:', e);
        return null;
      }
    },
  
    // Remove data from localStorage or sessionStorage
    remove(key, useSession = false) {
      const storage = useSession ? sessionStorage : localStorage;
      storage.removeItem(key);
    },
  
    // Clear all data from localStorage or sessionStorage
    clear(useSession = false) {
      const storage = useSession ? sessionStorage : localStorage;
      storage.clear();
    }
  };
  
  export default StorageService;
  