<template>
    <form id="contact-form" action="http://demo.hasthemes.com/limupa-v3/limupa/mail.php" method="post">
        <div class="form-group">
            <label>Your Name <span class="required">*</span></label>
            <input type="text" name="customerName" id="customername" required>
        </div>
        <div class="form-group">
            <label>Your Email <span class="required">*</span></label>
            <input type="email" name="customerEmail" id="customerEmail" required>
        </div>
        <div class="form-group">
            <label>Subject</label>
            <input type="text" name="contactSubject" id="contactSubject">
        </div>
        <div class="form-group mb-30">
            <label>Your Message</label>
            <textarea name="contactMessage" id="contactMessage"></textarea>
        </div>
        <div class="form-group">
            <button type="submit" value="submit" id="submit" class="li-btn-3" name="submit">send</button>
        </div>
    </form>
</template>

<script>
export default {
    name: 'Contact form'
}
</script>

<style scoped>

</style>