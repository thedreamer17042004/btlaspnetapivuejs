import { AccountService } from "@/service/accountService";


export default {
    namespaced: true,
    state: {
        data: [],
        pagination: {
            pageNumber:1,
            pageSize:10,
            total:100
        },
        success:false,
        loading: false,
        error: null
    },
    mutations: {
        SET_LOADING(state, payload) {
            state.loading = payload;
        },
        SET_DATA(state, payload) {
            state.data = payload;
        },
        SET_PAGINATE(state, payload) {
            state.pagination = payload;
        },
        SET_ERROR(state, payload) {
            state.error = payload;
        },
        SET_SUCCESS(state, payload) {
            state.success = payload;
        },
        SET_PAGE_NUMBER(state, pageNumber) {
            state.pagination.pageNumber = pageNumber;
        }
    },
    actions: {
        async fetchData({ commit }, data) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            try {
                const response = await AccountService.getAll(data);

                const paginate = {
                    pageNumber:response.data.pageNumber,
                    pageSize:response.data.pageSize,
                    total:response.data.totalRecords
                }
                commit('SET_PAGINATE', paginate)
              
                commit('SET_DATA', response.data.data);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
        async create({ commit }, formData) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            commit('SET_SUCCESS', false);
            try {

                const response = await AccountService.create(formData);
                
               
                commit('SET_SUCCESS', true);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
        async update({ commit },{ id, formData }) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            commit('SET_SUCCESS', false);
            try {

               
                const response = await AccountService.update(id,formData);

                commit('SET_SUCCESS', true);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
        async delete({ commit },id) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            commit('SET_SUCCESS', false);
            try {
                const response = await AccountService.delete(id);

                commit('SET_SUCCESS', true);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
        updatePageNumber({ commit }, pageNumber) {
            commit('SET_PAGE_NUMBER', pageNumber);
        },
    },
    getters: {
        data: state => state.data,
        loading: state => state.loading,
        error: state => state.error,
        success: state=>state.success,
        pagination: state=>state.pagination
    }

}