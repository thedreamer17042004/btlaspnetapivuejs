<template>
    <div class="main-content">
    
     <div class="page-content">
     <div class="container-fluid">
 
             <!-- start page title -->
             <div class="row">
                 <div class="col-12">
                     <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                         <h4 class="mb-sm-0">Attribute option</h4>
 
                         <div class="page-title-right">
                             <ol class="breadcrumb m-0">
                                 <li class="breadcrumb-item"><a href="javascript: void(0);">Edit</a></li>
                                 <li class="breadcrumb-item active">Attribute option</li>
                             </ol>
                         </div>
 
                     </div>
                 </div>
             </div>
             <!-- end page title -->
           <form-update></form-update>
        </div>
 
     </div>
    </div>
 </template>
 
 <script>
 import FormUpdate from '@/components/admin/update/FormUpdateAttributeOption.vue'
 
 export default{
     name: 'Edit attribute option',
     components: {
        FormUpdate
     },
     methods:{
         
     }
 }
 
 </script>
 
 <style scoped>
 </style>