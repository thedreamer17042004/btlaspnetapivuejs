<template>
    <breadcrumb first="Home" second="Register"></breadcrumb>

    <!-- Li's Breadcrumb Area End Here -->
    <!-- Begin Login Content Area -->
    <div class="page-section mb-60">
        <div class="container">
            <div class="row" style="justify-content:center;margin-top:5px">
                <div class="col-sm-12 col-md-12 col-lg-6 col-xs-12">
                 <form-register></form-register>
                </div>
            </div>
        </div>
    </div>

</template>


<script >
import FormRegister from '@/components/web/form/register/Register.vue'
import Breadcrumb from '@/components/web/breadcrumb/Breadcrumb.vue'
export default {
    name: 'Register',
    components: {
        FormRegister,
        Breadcrumb
    }
}

</script>

<style scoped></style>