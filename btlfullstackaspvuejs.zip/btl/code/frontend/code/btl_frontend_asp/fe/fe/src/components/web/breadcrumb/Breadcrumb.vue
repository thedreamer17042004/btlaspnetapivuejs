<template>
 <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <ul>
                    <li><a href="/">{{ first }}</a></li>
                    <li class="active">{{ second }}</li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script setup>

defineProps({
  first: String,
  second: String
})

</script>

<style scoped>

</style>