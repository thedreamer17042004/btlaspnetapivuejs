<template>
    <div id="layout-wrapper">
       <top-bar></top-bar>
       <side-bar></side-bar>

       <router-view />

       <footer-admin></footer-admin>
    </div>
</template>

<script>
//import
import TopBar from '@/components/admin/topbar/PageTopBar.vue';
import SideBar from '@/components/admin/sidebar/Sidebar.vue';
import FooterAdmin from '@/layouts/admin/footer/Footer.vue';

// css
import '@/assets/admin/libs/jsvectormap/css/jsvectormap.min.css'
import '@/assets/admin/js/layout.js'
import '@/assets/admin/css/bootstrap.min.css'
import '@/assets/admin/css/icons.min.css'
import '@/assets/admin/css/app.min.css'
import '@/assets/admin/css/custom.min.css'

export default {
   name: 'Admin Layout',
   components: {
       TopBar,
       SideBar,
       FooterAdmin
   }
}
</script>

<style scoped></style>