
export default {
  namespaced: true,
  state: {
    isShowSideBar: true
  },
  getters: {
    getIsShowSideBar(state) {
      return state.isShowSideBar
    }
  },
  mutations: {
    setIsShowSideBar(state) {
      state.isShowSideBar = !state.isShowSideBar
    }
  }
}