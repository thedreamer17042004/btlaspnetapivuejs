<template>
    <form method="post" @submit.prevent="submitForm" >
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="AttributeCode" class="form-label ">
                                AttributeCode<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="AttributeCode"
                                    v-model="formData.AttributeCode" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.attributecode" class="text-danger">{{ errors.attributecode }}</span>
                        </div>
                     
                        <div>
                            <label asp-for="AttributeName" class="form-label ">
                                AttributeName<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="AttributeName"
                                    v-model="formData.AttributeName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.attributename" class="text-danger">{{ errors.attributename }}</span>
                        </div>
                    </div>
                </div>
            </div>

         

        </div>


     
        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'
import { AttributeService } from "@/service/attributeService";

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'AttributeCode': '',
                'AttributeName': '',
                
            },
          
        }
    },
    methods: {
        ...mapActions('attribute', ['update']),
       
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.AttributeCode) {
                this.errors.name = 'Attribute code is required';
                isValid = false;
            }

          
             if (!this.formData.AttributeName){
                this.errors.active = 'Attribute name is required';
                isValid = false;
            }

            return isValid;
        },
      
         submitForm() {
            if(this.validate()){

                const formData = {
                    'AttributeCode': this.formData.AttributeCode,
                    'AttributeName': this.formData.AttributeName,
                }

                this.update({id:this.$route.params.id,formData});
            }
        },
        
        async fetchAttributeDetails(id) {
            var response =  await  AttributeService.findById(id);
            this.mapFormData(response.data);
        },
        mapFormData(data) {
            this.formData = {
                AttributeCode: data.attributeCode,
                AttributeName: data.attributeName,
                
            };
        }
    },
    computed: {
        ...mapState('attribute',[
        'success'
      ]),
    },
    watch: {
        'success':  function() {
          if(this.success==true){
            const {showSuccess, showError} = useNotification();
            showSuccess();
            this.$router.push({name:'attribute'})
          }
        }
       
    },
    mounted() {
        const id = this.$route.params.id;
        this.fetchAttributeDetails(id);
    },
}
</script>

<style scoped></style>