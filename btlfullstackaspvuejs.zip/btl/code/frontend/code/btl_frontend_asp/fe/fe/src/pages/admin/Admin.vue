<template>
    <h1>This is admin page</h1>
</template>