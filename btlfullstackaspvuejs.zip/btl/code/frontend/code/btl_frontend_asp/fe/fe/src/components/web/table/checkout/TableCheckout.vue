<template>
    <table class="table">
        <thead>
            <tr>
                <th class="cart-product-name">Product</th>
                <th class="cart-product-total">Total</th>
            </tr>
        </thead>
        <tbody>
            <tr class="cart_item">
                <td class="cart-product-name"> Vestibulum suscipit<strong class="product-quantity"> × 1</strong></td>
                <td class="cart-product-total"><span class="amount">£165.00</span></td>
            </tr>
            <tr class="cart_item">
                <td class="cart-product-name"> Vestibulum suscipit<strong class="product-quantity"> × 1</strong></td>
                <td class="cart-product-total"><span class="amount">£165.00</span></td>
            </tr>
        </tbody>
        <tfoot>
            <tr class="cart-subtotal">
                <th>Cart Subtotal</th>
                <td><span class="amount">£215.00</span></td>
            </tr>
            <tr class="order-total">
                <th>Order Total</th>
                <td><strong><span class="amount">£215.00</span></strong></td>
            </tr>
        </tfoot>
    </table>
</template>

<script>
export default {
    name:'Table checkout'
}
</script>

<style scoped></style>