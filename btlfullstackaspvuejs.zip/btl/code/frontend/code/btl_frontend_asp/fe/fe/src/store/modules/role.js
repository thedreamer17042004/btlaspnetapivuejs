import { AccountService } from "@/service/accountService";


export default {
    namespaced: true,
    state: {
        data: [],
        pagination: {
            pageNumber:1,
            pageSize:10,
            total:100
        },
        success:false,
        loading: false,
        error: null
    },
    mutations: {
        SET_LOADING(state, payload) {
            state.loading = payload;
        },
        SET_DATA(state, payload) {
            state.data = payload;
        },
        SET_PAGINATE(state, payload) {
            state.pagination = payload;
        },
        SET_ERROR(state, payload) {
            state.error = payload;
        },
        SET_SUCCESS(state, payload) {
            state.success = payload;
        }
    },
    actions: {
        async fetchData({ commit }) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            try {
                const response = await AccountService.getAll();
                console.log(response.data)
                const paginate = {
                    pageNumber:response.pageNumber,
                    pageSize:response.pageSize,
                    total:response.totalRecords
                }
                commit('SET_DATA', response.data.data);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
        async create({ commit }, formData) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            try {

                const response = await AccountService.create(formData);
                console.log(response.data)
               
                commit('SET_SUCCESS', true);
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },
    },
    getters: {
        data: state => state.data,
        loading: state => state.loading,
        error: state => state.error,
    }

}