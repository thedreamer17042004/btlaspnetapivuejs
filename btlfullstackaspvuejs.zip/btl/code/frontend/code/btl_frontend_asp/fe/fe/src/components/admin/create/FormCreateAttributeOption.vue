<template>

    <form method="post" @submit.prevent="submitForm">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="OptionName" class="form-label ">
                                Option name<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="OptionName"
                                    v-model="formData.OptionName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.optionname" class="text-danger">{{ errors.optionname }}</span>
                        </div>

                        <div class="col-12" style="padding-left: 0px;">
                            <label asp-for="AttributeId" class="form-label mt-1">
                                Attribute<span style="color:red">(*)</span>
                            </label>
                            <select v-model="formData.AttributeId" id="AttributeId" class="form-select mb-3"
                                aria-label="Default select example">
                                <option value="">Select your attribute</option>
                                <option v-for="item in data" :key="item.attributeId" :value="item.id ">{{ item.attributeName }}</option>
                               
                            </select>
                            <span v-if="errors.attributeId" class="text-danger">{{ errors.attributeId }}</span>
                        </div>
                       
                    </div>
                </div>
            </div>

        </div>


        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapGetters, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'OptionName': '',
                'AttributeId': ''
            }
        }
    },
    methods: {
        ...mapActions('attributeoption', ['create']),
        ...mapActions('attribute', ['fetchData']),
        getData() {
          const data=  {
                'PageNumber':1,
                'PageSize':100,
                'Keyword':'',
                'Status': ''
            }
            this.fetchData(data);
        },
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.OptionName) {
                this.errors.optionname = 'Option name is required';
                isValid = false;
            }
            if (!this.formData.AttributeId) {
                this.errors.attributeId = 'Attribute is required';
                isValid = false;
            }
            return isValid;
        },
        async submitForm() {
            if(this.validate()){
                
                this.create(this.formData);
            }
        },
    },
    computed: {
        ...mapState('attributeoption',[
        'success'
      ]),
      ...mapGetters('attribute', ['data']),
    },
    watch: {
        'success':  function() {
            const {showSuccess, showError} = useNotification();
          if(this.success==true){
            showSuccess();
            this.$router.push({name:'attributeoption'})   
          }
        }
    },
    created() {
        this.getData();
    }
}
</script>

<style scoped></style>