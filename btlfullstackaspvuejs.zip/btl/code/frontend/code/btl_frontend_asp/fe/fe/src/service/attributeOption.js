import auth from "@/store/modules/auth";
import axios from "axios";

export class AttributeOptionService {
    /**
     ******************************
     * @API
     ******************************
     */
  
    static async getAll (data) {
      try {
        const response = await axios.post(`https://localhost:7038/api/attributeoption/search`, data, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async create (formData) {
      try {
       
        const response = await axios.post(`https://localhost:7038/api/attributeoption`, 
           formData
        , {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async findById (id) {
      try {
       
        const response = await axios.get(`https://localhost:7038/api/attributeoption/`+id, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async update (id, body) {
      try {
       console.log(body)
        const response = await axios.put(`https://localhost:7038/api/attributeoption/${id}`,body,
          {
            headers: {
              'Content-Type': 'application/json' ,
              'Authorization': `Bearer ${auth.state.data}`,
            }
          }
          );
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async delete (id) {
      try {
   
        const response = await axios.delete(`https://localhost:7038/api/attributeoption/${id}`, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async findByAttributeId (id) {
      try {
        const response = await axios.get(`https://localhost:7038/api/attributeoption/getbyattribute/${id}`,  {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }
  
   
  }
  