import { useNotification } from "@/components/admin/notification/Notification";
import axios from "axios";
import auth from "@/store/modules/auth";
export class AuthService {
    /**
     ******************************
     * @API
     ******************************
     */
  
    static async login (data) {
      try {
        const response = await axios.post(`https://localhost:7038/api/auth/login`, data);
        return response;
      } catch (error) {
        const {showSuccess, showError} = useNotification();
        console.log(error)
        showError();
      }
    }

  
  }
  