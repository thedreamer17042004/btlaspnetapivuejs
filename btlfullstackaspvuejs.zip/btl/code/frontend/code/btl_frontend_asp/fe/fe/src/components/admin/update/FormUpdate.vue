<template>
    <form method="post" @submit.prevent="submitForm" enctype="multipart/form-data">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="Username" class="form-label ">
                                Username<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="Username"
                                    v-model="formData.Username" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.username" class="text-danger">{{ errors.username }}</span>
                        </div>
                        <div class="mt3">
                            <label asp-for="Email" class="form-label mt-1">
                                Email<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input readonly type="email" class="form-control form-control-icon" value="" id="Email"
                                    v-model="formData.Email" placeholder="example@gmail.com">
                                <i class="ri-mail-unread-line"></i>
                            </div>
                            <span v-if="errors.email" class="text-danger">{{ errors.email }}</span>
                        </div>
                        <div>
                            <label asp-for="Password" class="form-label mt-1">
                                Password<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input readonly type="text" class="form-control form-control-icon" value="" id="Password"
                                    v-model="formData.Password" placeholder="">
                                <i class="ri-lock-2-line"></i>
                            </div>
                            <span v-if="errors.password" class="text-danger">{{ errors.password }}</span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Other infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label mt-1">
                                    Gender
                                </label>
                                <select v-model="formData.Gender" id="Gender" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option selected value="1">Male</option>
                                    <option value="2">Female</option>
                                </select>
                                
                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>


        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Address and phone</h4>
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div>
                            <label asp-for="Phone" class="form-label ">
                                Phone
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" value="" id="Phone"
                                    v-model="formData.Phone" placeholder="">
                                <i class="bx bx-phone"></i>

                            </div>
                          
                        </div>
                        <div class="mt3">
                            <label asp-for="Address" class="form-label mt-1">
                                Address
                            </label>
                            <textarea class="form-control" rows="3" placeholder="" id="Address"
                                v-model="formData.Address"></textarea>
                        </div>
                       
                    </div>
                </div>

            </div>

            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Role image</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div class="col-12" style="padding-left: 0px;">
                            <label asp-for="RoleId" class="form-label mt-1">
                                Role<span style="color:red">(*)</span>
                            </label>
                            <select v-model="formData.Role" id="Role" class="form-select mb-3"
                                aria-label="Default select example">
                                <option value="">Select your role</option>
                                <option v-for="item in roles" :key="item.id" :value="item.id ">{{ item.name }}</option>
                               
                            </select>
                            <span v-if="errors.role" class="text-danger">{{ errors.role }}</span>
                        </div>
                        <div class="mt3">
                            <label for="iconrightInput" class="form-label mt-1">
                                Avatar
                            </label>
                            <div class="form-icon right">
                                <input type="file" name="Avatar" @change="handleFile" accept="image/*" class="form-control form-control-icon"
                                    id="Avatar">
                                <i class="mdi mdi-file-image-minus-outline"></i>
                            </div>
                            <img :src="formData.Avatar" v-if="formData.Avatar" width="100px"/>
                            <p v-else>No image available</p>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'
import { AccountService } from "@/service/accountService";

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'Email': '',
                'Username': '',
                'Password': '',
                'Role': '',
                'Phone': '',
                'Address': '',
                'Gender': '',
                'Avatar': ''
            },
            roles:[
                {id:'436826e8-3a80-4258-8d16-c4a3e6348bd6',name:'Admin'},
                {id:'4f31ba9b-8cc7-4745-942b-c3b05891445c', name:'Manager'},
                {id:'e4ee1684-7f08-4218-9f2d-f7c2a9efcb53', name: 'User'}
            ],
        }
    },
    methods: {
        ...mapActions('account', ['update']),
        isPasswordValid() {
            const password = this.password;
            const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            return passwordRegex.test(password);
        },
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.Username) {
                this.errors.username = 'Username is required';
                isValid = false;
            }

            if (!this.formData.Email) {
                this.errors.email = 'Email is required';
                isValid = false;
            } else if (!/\S+@\S+\.\S+/.test(this.formData.Email)) {
                this.errors.email = 'Email must be valid';
                isValid = false;
            }
             if (!this.formData.Password){
                this.errors.password = 'Password is required';
                isValid = false;
            }else if(this.isPasswordValid()) {
                this.errors.password = 'Password must be at least 8 characters long, include an uppercase letter, a lowercase letter, a number, and a special character.';
                isValid = false;
            }
             if (!this.formData.Role){
                this.errors.role = 'Role is required';
                isValid = false;
            }

            return isValid;
        },
        handleFile(event) {
            this.file = event.target.files[0]; 
        },
       async fetchImage1() {
            const image = await AccountService.fetchImage(this.formData.Avatar);
            this.formData.Avatar = image;
        },
        async submitForm() {
            if(this.validate()){
                var formData = new FormData();
                if(this.file){
                    formData.append('Avatar', this.file)
                }
                formData.append('Email', this.formData.Email)
                formData.append('Username', this.formData.Username)
                formData.append('Password', this.formData.Password)
                formData.append('Role', this.formData.Role)
                formData.append('Phone', this.formData.Phone)
                formData.append('Address', this.formData.Address)
                formData.append('Gender', this.formData.Gender)
                this.update({ id: this.$route.params.id, formData });
            }
        },
        async fetchAccountDetails(id) {
            var response =  await  AccountService.findById(id);
            this.mapFormData(response.data);
            this.fetchImage1();
        },
        mapFormData(data) {
            this.formData = {
                Address: data.address || '',
                Gender: data.gender?'1':'0' || '',
                Avatar: data.avatar || '',
                Id: data.id || '',
                Username: data.userName || '',
                Email: data.email || '',
                Phone: data.phoneNumber || '',
                Role:data.roleName,
                Password:data.passwordHash || ''
            };
        }
    },
    computed: {
        ...mapState('account',[
        'success'
      ])
    },
    watch: {
        'success':  function() {
          if(this.success){
            const {showSuccess, showError} = useNotification();
            showSuccess();
            this.$router.push({name:'account'})
          }
        }
       
    },
    mounted() {
        const id = this.$route.params.id;
        this.fetchAccountDetails(id);
       
    },
}
</script>

<style scoped></style>