<template>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Category</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Table</a>
                                    </li>
                                    <li class="breadcrumb-item active">Category</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header" style="display:flex;justify-content: space-between">
                                <div class="col-3" style="padding-left: 0px;">
                                    <router-link :to="{ name: 'createcategory' }" style="color:white "
                                        class="btn btn-primary waves-effect waves-light">Add new</router-link>
                                </div>

                                <div class="col-9">
                                    <form-search></form-search>

                                </div>

                            </div>
                            <div class="card-body">
                                <form-table></form-table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- container-fluid -->
        </div>
        <!-- End Page-content -->
    </div>
</template>

<script>
import FormTable from '@/components/admin/table/FormTableCategory.vue';
import FormSearch from '@/components/admin/search/FormSearchCategory.vue';
import { mapMutations, mapState, mapActions, mapGetters } from 'vuex'

export default {
    name: 'Account page',
    setup() {
        const notify = () => {
            toast.error("Wow so easy !", {
                autoClose: 1000,
            }); // ToastOptions
        }
        return { notify };
    },
    components: {
        FormTable,
        FormSearch
    },
    methods: {
        ...mapActions('category', ['fetchData','delete']),
        getData() {
          const data=  {
                'PageNumber':1,
                'PageSize':10,
                'Keyword':'',
                'Status': ''
            }
            this.fetchData(data);
        },
      
    },
    computed: {
        ...mapGetters('category', ['data', 'loading', 'error', 'success']),
    },
    created() {
        this.getData();
    },
    watch: {
        'success': function() {
            if(this.success){
                this.getData();
            }
        }
    }
   
}

</script>
<style scoped></style>