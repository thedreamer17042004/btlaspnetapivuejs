<template>
  <div>
    <div id="form-container">
      <div style="
    display: flex;
    padding: 10px;
    gap: 10px;" v-for="(form, index) in forms" :key="form.Id" >
        <select class="attribute-select form-select mb-3" @change="updateAttribute($event, index)">
          <option value="">Select Attribute</option>
          <option v-for="attribute in data" :key="attribute.id" :value="attribute.id">
            {{ attribute.attributeName }}
          </option>
        </select>
        <select class="options-select form-select mb-3" @change="updateOption($event, index)">
          <option value="">Select Option</option>
          <option v-for="option in options[index]" :key="option.id" :value="option.id">
            {{ option.optionName }}
          </option>
        </select>
        <button style="padding: 5px;
    height: 45px;" @click.prevent="removeForm(form.Id, index)" class="btn btn-danger">Delete</button>
      </div>
    </div>
    <button @click.prevent="duplicateForm" :class="{ hidden: isAddButtonHidden }" style="
    margin-left: 10px;
    margin-bottom: 10px;
" class="button-add btn btn-danger">Add More</button>
  </div>
</template>

<script>
import axios from 'axios';
import { mapActions, mapGetters } from 'vuex';
import { AttributeOptionService } from '@/service/attributeOption';
import { AttributeService } from '@/service/attributeService';
export default {
  name: 'attribute',
  data() {
    return {
      forms: [
        {Id: 0,AttributeId:'', OptionId: ''},
      ], // Array to hold form data
      attributes: [], // Array to hold fetched attributes
      options: [[]], // Array to hold options for each form
      isAddButtonHidden: false, // To control the visibility of the Add button,
      identity: 1

    };
  },
  mounted() {
    // this.checkCount();
  },
  computed: {
    ...mapGetters('attribute', ['data']),
  },
  methods: {
    ...mapActions('attribute', ['fetchData']),

    async updateAttribute(event, index) {
      const attributeId = event.target.value;
      this.forms[index].AttributeId = attributeId; // Update the attributeId in forms array
      await this.updateOptions(attributeId, index); // Fetch and update options based on the attributeId
      this.emitFormData();
    },
    updateOption(event, index) {
      const optionId = event.target.value;
      this.forms[index].OptionId = optionId; // Update the optionId in forms array
      this.emitFormData();
    },

    getData() {
      const data = {
        'PageNumber': 1,
        'PageSize': 100,
        'Keyword': '',
        'Status': ''
      }
      this.fetchData(data);
    },
    async updateOptions(attributeId, index) {
    
      if (attributeId) {
        try {
          const response = await AttributeOptionService.findByAttributeId(attributeId)

          this.options[index] = response.data;
        } catch (error) {
          console.error('Error fetching options', error);
        }
      } else {
        this.options[index] = [];
      }
    },
    duplicateForm() {
      this.forms.push({Id: this.identity,AttributeId:'', OptionId: ''})
      this.identity++;
      this.options.push([]);
      // this.checkCount();
    },
    emitFormData() {
      this.$emit('update:forms', this.forms); // Emit the forms array to the parent component
    },
    async checkCount() {
      try {
        const data = {
          'PageNumber': 1,
          'PageSize': 100,
          'Keyword': '',
          'Status': ''
        }
        const response = await AttributeService.getAll(data);

        const attributeCount = response.data.totalRecords;
        this.isAddButtonHidden = this.forms.length >= attributeCount;
      } catch (error) {
        console.error('Error fetching attributes', error);
      }
    },
    removeForm(index, key) {
      if (this.forms.length >= 1) {
        // Remove the form from the array
        let indexToRemove = this.forms.findIndex(form => form.Id === index);


        if (indexToRemove !== -1) {
          // Remove the object at the found index
          this.forms.splice(indexToRemove, 1);
          this.options.splice(key, 1);
        }
        this.emitFormData();
      } else {
        // alert("At least one form must be present.");
      }
      // this.checkCount();
    },
  },

  created() {
    this.getData();
  }
};
</script>

<style scoped>
.hidden {
  display: none;
}
</style>