<template>

    <form method="post" @submit.prevent="submitForm">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="AttributeCode" class="form-label ">
                                Attribute Code<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="AttributeCode"
                                    v-model="formData.AttributeCode" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.attributecode" class="text-danger">{{ errors.attributecode }}</span>
                        </div>
                        <div>
                            <label asp-for="AttributeName" class="form-label ">
                                AttributeName<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="AttributeName"
                                    v-model="formData.AttributeName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.attributename" class="text-danger">{{ errors.attributename }}</span>
                        </div>
                       
                    </div>
                </div>
            </div>

        </div>


        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'AttributeCode': '',
                'AttributeName': ''
            }
        }
    },
    methods: {
        ...mapActions('attribute', ['create']),
      
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.AttributeCode) {
                this.errors.attributecode = 'Attribute code is required';
                isValid = false;
            }

           
             if (!this.formData.AttributeName){
                this.errors.attributename = 'Attribute name is required';
                isValid = false;
            }

            return isValid;
        },
        async submitForm() {
            if(this.validate()){
                
                this.create(this.formData);
            }
        },
    },
    computed: {
        ...mapState('attribute',[
        'success'
      ])
    },
    watch: {
        'success':  function() {
            const {showSuccess, showError} = useNotification();
          if(this.success==true){
            showSuccess();
            this.$router.push({name:'attribute'})   
          }
        }
    },
}
</script>

<style scoped></style>