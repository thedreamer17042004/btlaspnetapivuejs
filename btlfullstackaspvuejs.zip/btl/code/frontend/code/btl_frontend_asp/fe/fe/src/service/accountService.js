import axios from "axios";
import auth from "@/store/modules/auth";

export class AccountService {
    /**
     ******************************
     * @API
     ******************************
     */
  
    static async getAll (data) {
      try {
        const response = await axios.post(`https://localhost:7038/api/account/search`, data, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          },
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async create (formData) {
      try {
       
        const response = await axios.post(`https://localhost:7038/api/account`, 
           formData
        , {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${auth.state.data}`,
          },
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async findById (id) {
      try {
       
        const response = await axios.get(`https://localhost:7038/api/account/`+id, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async update (id, body) {
      try {
       console.log(body)
        const response = await axios.put(`https://localhost:7038/api/account/${id}`,body, {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${auth.state.data}`,
          },
        } );
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }

    static async delete (id) {
      try {
   
        const response = await axios.delete(`https://localhost:7038/api/account/${id}`, {
          headers: {
            'Authorization': `Bearer ${auth.state.data}`,
          }
        });
        console.log(response)
        return response;
      } catch (error) {
        console.log(error)
      }
    }



    static async fetchImage(fileName) {
      try {

        if(fileName!=''){
          var response = await axios.get('https://localhost:7038/api/account/getimage/'+fileName, {
            responseType: 'blob' // Important: This tells axios to treat the response as a Blob
          }, {
            headers: {
              'Authorization': `Bearer ${auth.state.data}`,
            }
          });

          var result=  URL.createObjectURL(new Blob([response.data]));
          // var result=  URL.createObjectURL(new Blob([response.data], { type: ['image/png', 'image/jpg'] }));

            // URL.revokeObjectURL(result);
            return result;
        }
     
        return '';
      
      } catch (error) {
        console.error('Error fetching the image:', error);
      }
    }
  
   
  }
  