<template>
    <form method="post" @submit.prevent="submitForm" enctype="multipart/form-data">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="Username" class="form-label ">
                                Product Name<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="Username"
                                    v-model="formData.ProductName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.productname" class="text-danger">{{ errors.productname }}</span>
                        </div>
                        <div class="mt3">
                            <label asp-for="Email" class="form-label mt-1">
                                Price<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="number" class="form-control form-control-icon" value="" id="Email"
                                    v-model="formData.Price" placeholder="Enter price">
                                <i class="ri-mail-unread-line"></i>
                            </div>
                            <span v-if="errors.price" class="text-danger">{{ errors.price }}</span>
                        </div>
                        <div>
                            <label class="form-label mt-1">
                                Sale price
                            </label>
                            <div class="form-icon right">
                                <input type="number" class="form-control form-control-icon" value="" id="SalePrice"
                                    v-model="formData.SalePrice" placeholder="">
                                <i class="ri-lock-2-line"></i>
                            </div>
                            <span v-if="errors.saleprice" class="text-danger">{{ errors.saleprice }}</span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Other infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label mt-1">
                                    Active
                                </label>
                                <select v-model="formData.Active" id="Gender" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option selected value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>

                            </div>

                            <div class="col-12">
                                <label class="form-label mt-1">
                                    Category
                                </label>
                                <select v-model="formData.CategoryId" id="Gender" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option v-for="item in data" :key="item.id" :value="item.id">{{ item.categoryName
                                        }}</option>
                                </select>

                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>


        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Image and album</h4>
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="mt3">
                            <label for="iconrightInput" class="form-label mt-1">
                                Image
                            </label>
                            <div class="form-icon right">
                                <input type="file" name="Image" @change="handleFile" accept="image/*"
                                    class="form-control form-control-icon" id="Image">
                                <i class="mdi mdi-file-image-minus-outline"></i>
                            </div>
                            <img v-if="formData.Image" :src="formData.Image" width="100px" alt="Image here" />
                            <!-- Optionally, display a placeholder or message if no image is available -->
                            <p v-else>No image available</p>
                        </div>
                        <div class="mt3">
                            <label for="iconrightInput" class="form-label mt-1">
                                Album
                            </label>
                            <div class="form-icon right">
                                <input type="file" name="Album" @change="handleFileChange" multiple accept="image/*"
                                    class="form-control form-control-icon" id="Album">
                                <i class="mdi mdi-file-image-minus-outline"></i>
                            </div>

                        </div>
                        <div v-if="album.length" class="image-container">
                            <div v-for="(image, index) in album" :key="index" class="image-preview"
                                draggable="true">
                                <img :src="image" alt="Image preview" width="100px" />
                                <i class="ri-chat-delete-line icon-check" @click="removeImage(index)"></i>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Description</h4>

                        </div><!-- end card header -->
                        <div class="card-body">
                            <!-- <div id="editor" ref="editor"></div> -->
                            <!-- <input type="hidden" id="Description" name="Description" v-model="formData.Description" /> -->
                            <textarea name="Description" style="height: 300px;"
                                v-model="formData.Description"></textarea>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import { mapActions, mapGetters, mapState } from 'vuex'
import { useNotification } from '@/components/admin/notification/Notification.js'
import { ProductService } from "@/service/productService";
import { AccountService } from "@/service/accountService";
import { onMounted } from 'vue';

export default {
    name: 'Form update',
    data() {
        return {
            errors: {},
            file: null,
            imagePreviews: [],
            uploadedFiles: [],
            oldFiles:[],
            album: [],
            formData: {
                'ProductName': '',
                'Price': '',
                'SalePrice': '',
                'Active': '',
                'Image': '',
                'ProductName': '',
                'CategoryId': '',
                'Album': '',
                'Description': ''
            },
        }
    },
    // setup() {
    //     const imagePreviews = ref([]); // Array for previewing images
    //     const uploadedFiles = ref([]); // Array to store newly uploaded files


    //     onMounted(async () => {
    //         const id = this.$route.params.id;
    //         var response = await ProductService.findById(id);

    //         const images = JSON.parse(response.album);

    //         // Fetch image URLs for each filename (if necessary)
    //         for (const element of images.value) {
    //             const imageUrl = await fetchImage1(element);
    //             imagePreviews.value.push(imageUrl);
    //         }
    //     });



    //     const handleFileChange = (event) => {
    //         const files = event.target.files;
    //         imagePreviews.value = [];

    //         for (const file of files) {
    //             const reader = new FileReader();
    //             reader.onload = (e) => {
    //                 imagePreviews.value.push(e.target.result);
    //             };
    //             reader.readAsDataURL(file); // Read the file as a data URL
    //             uploadedFiles.value.push(file)
    //         }
    //     };

    //     const removeImage = (index) => {
    //         imagePreviews.value.splice(index, 1); // Remove image at the specified index
    //         uploadedFiles.value.splice(index, 1); // Remove image at the specified index
    //     };

    //     return {
    //         imagePreviews,
    //         handleFileChange,
    //         removeImage,
    //         uploadedFiles
    //     }

    // },

    methods: {
        ...mapActions('product', ['update']),
        ...mapActions('category', ['fetchData']),
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.ProductName) {
                this.errors.productname = 'ProductName is required';
                isValid = false;
            }

            if (!this.formData.Price) {
                this.errors.price = 'Price is required';
                isValid = false;
            }

            if (!this.formData.CategoryId) {
                this.errors.categoryid = 'Categoryid is required';
                isValid = false;
            }

            return isValid;
        },
        async fetchImage1() {
            const image = await AccountService.fetchImage(this.formData.Image);
            this.formData.Image = image

        },
        handleFile(event) {
            this.file = event.target.files[0];
        },
        async submitForm() {
            if (this.validate()) {
                var formData = new FormData();
                if (this.file) {
                    formData.append('Image', this.file)
                }
                formData.append('ProductName', this.formData.ProductName)
                formData.append('Price', this.formData.Price)
                formData.append('SalePrice', this.formData.SalePrice)
                formData.append('Active', this.formData.Active)
                formData.append('CategoryId', this.formData.CategoryId)
                formData.append('Description', this.formData.Description)
                formData.append('OldImage', JSON.stringify(this.oldFiles))
                this.uploadedFiles.forEach(file => {
                    formData.append('Album', file);
                });

                this.update({ id: this.$route.params.id, formData });
            }
        },
        async fetchProductDetails(id) {
            var response = await ProductService.findById(id);
            this.mapFormData(response.data);
            this.fetchImage1();
            this.fetchAlbum(response);
        },
        mapFormData(data) {
            this.formData = {
                ProductName: data.productName || '',
                Price: data.price || '',
                SalePrice: data.salePrice || 0,
                Image: data.image || '',
                Active: data.active ? '1' : '0' || '',
                CategoryId: data.categoryId || '',
                Album: data.album,
                Description: data.description || ''
            };
        },
        getData() {
            const data = {
                'PageNumber': 1,
                'PageSize': 100,
                'Keyword': '',
                'Status': ''
            }
            this.fetchData(data);
        },
        handleFileChange(event) {
            const files = event.target.files;
            // this.album = [];
            // this.uploadedFiles = [];

            for (const file of files) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    this.album.push(e.target.result);
                };
                reader.readAsDataURL(file);
                this.uploadedFiles.push(file);
            }
        },
        removeImage(index) {
            this.album.splice(index, 1);
            this.uploadedFiles.splice(index, 1);
            this.oldFiles.splice(index, 1);
        },

        async fetchAlbum(response) {
            try {
                const data = response?.data;
                const album1 = JSON.parse(data.album); // Adjust based on your data format
    
                for (const element of album1) {
                    const image = await AccountService.fetchImage(element);
                    this.album.push(image);  // Store the album data
                    this.oldFiles.push(element)
               }
           
            } catch (error) {
                console.error("Error fetching album:", error);
            }
        }
    },
    computed: {
        ...mapState('product', ['success']),
        ...mapGetters('category', ['data']),
    },
    watch: {
        'success': function () {
            if (this.success) {
                const { showSuccess, showError } = useNotification();
                showSuccess();
                this.$router.push({ name: 'product' })
            }
        }

    },
   async mounted() {
        const id = this.$route.params.id;
        this.fetchProductDetails(id);
        this.getData();

    },

}
</script>


<style scoped>
.image-container {
    display: flex;
    gap: 30px;
    padding: 10px;
    flex-wrap: wrap;
    justify-content: center;
}

.image-preview {
    border: 1px solid #e9e9d5;
    position: relative;
}

.icon-check {
    position: absolute;
    top: -9px;
    left: -14px;
    font-size: 20px;
    cursor: pointer;
}
</style>