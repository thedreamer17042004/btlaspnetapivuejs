
import { useToast } from "vue-toastification";

export const useNotification = () => {
  const toast = useToast();
  const showSuccess = (message = 'Success') => {
    toast.success(message,{
      position: 'top-right',
      timeout: 2000,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    })
  };

  const showError = (message = 'Fail') => {
    toast.error(message,{
      position: 'top-right',
      timeout: 2000,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    })
  };

  return { showSuccess, showError };
};
