// src/utils/jwtUtils.js

import { jwtDecode } from 'jwt-decode'; // Named import

/**
 * Decodes the JWT token and returns the payload.
 * @param {string} token - The JWT token to decode.
 * @returns {object} - The decoded payload.
 */
export function decodeToken(token) {
  try {
    return jwtDecode(token);
  } catch (error) {
    console.error('Invalid token', error);
    return {};
  }
}

/**
 * Checks if the JWT token is expired.
 * @param {string} token - The JWT token to check.
 * @returns {boolean} - True if the token is expired, otherwise false.
 */
export function isTokenExpired(token) {
  const decoded = decodeToken(token);
  if (decoded.exp) {
    conscurrentTimet  = Math.floor(Date.now() / 1000);
    return decoded.exp < currentTime;
  }
  return true; // Default to true if expiration is not defined
}

/**
 * Gets the user's role from the JWT token.
 * @param {string} token - The JWT token to decode.
 * @returns {string} - The user's role or 'Guest' if not found.
 */
export function getUserRole(token) {
  const decoded = decodeToken(token);
  return decoded.role || 'User';
}

/**
 * Gets the user ID from the JWT token.
 * @param {string} token - The JWT token to decode.
 * @returns {string} - The user ID or 'Unknown' if not found.
 */
export function getUserId(token) {
  const decoded = decodeToken(token);
  return decoded.sub || 'Unknown';
}
