<template>

<form @submit.prevent="submitForm" method="get" style="display:flex;height: 36px">
    <div class="input-group">
        <input type="text" class="form-control" v-model="formData.search" id="search"  value="" placeholder="Search ...">
        <button type="submit" class="btn btn-success waves-effect waves-light"><i class="las la-search"></i></button>
    </div>
</form>
</template>

<script>
import { mapActions, mapGetters, mapMutations} from 'vuex';
export default {
    name: 'Form search',
    data() {
        return {
            formData: {
                search: ''
            },
        }
    },
    methods: {
        ...mapActions('attributeoption', ['fetchData']),
        submitForm() {
            const paginate = {
                pageNumber: 1,
                pageSize: 1,
                Keyword:this.formData.search
            }
            this.fetchData(paginate);
        },
    },

}
</script>

<style scoped>
</style>