import { AuthService } from "@/service/authService";
import StorageService from "@/service/storage";


export default {
    namespaced: true,
    state: {
        data: localStorage.getItem('token') || null, // Retrieve token from localStorage
        success:false,
        loading: false,
        error: null
    },
    mutations: {
        SET_LOADING(state, payload) {
            state.loading = payload;
        },
        SET_DATA(state, payload) {
            state.data = payload;
        },
        SET_ERROR(state, payload) {
            state.error = payload;
        },
        SET_SUCCESS(state, payload) {
            state.success = payload;
        },

    },
    actions: {
        async login({ commit }, data) {
            commit('SET_LOADING', true);
            commit('SET_ERROR', null);
            commit('SET_SUCCESS', false)
            try {
                const response = await AuthService.login(data);
                //  StorageService.set('token', response.data.token);
                localStorage.setItem('token', response.data.token)
                commit('SET_DATA', response.data.token);
                commit('SET_SUCCESS', true)
            } catch (error) {
                commit('SET_ERROR', error.message || 'Failed to fetch repositories');
            } finally {
                commit('SET_LOADING', false);
            }
        },

        logout({ commit }) {
            commit('SET_LOADING', false);
            localStorage.removeItem('token')
            commit('SET_DATA', null);
            commit('SET_SUCCESS', false);
        },
        
    },
    getters: {
        data: state => state.data,
        loading: state => state.loading,
        error: state => state.error,
        success: state=>state.success,
    }

}