<template>
    <form method="post" @submit.prevent="submitForm" >
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="Name" class="form-label ">
                                Name<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="CategoryName"
                                    v-model="formData.CategoryName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.name" class="text-danger">{{ errors.name }}</span>
                        </div>
                        <div >
                                <label class="form-label mt-1">
                                    Active
                                </label>
                                <select v-model="formData.Active" id="Active" class="form-select mb-3"
                                    aria-label="Default select example">
                                    <option selected value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                                
                            </div>

                    </div>
                </div>
            </div>

         

        </div>


     
        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'
import { CategoryService } from "@/service/categoryService";

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'CategoryName': '',
                'Active': '',
                
            },
          
        }
    },
    methods: {
        ...mapActions('category', ['update']),
       
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.CategoryName) {
                this.errors.name = 'Name is required';
                isValid = false;
            }

          
             if (!this.formData.Active){
                this.errors.active = 'Active is required';
                isValid = false;
            }

            return isValid;
        },
      
         submitForm() {
            if(this.validate()){

                const formData = {
                    'CategoryName': this.formData.CategoryName,
                    'Active': this.formData.Active,
                }
                console.log(this.formData.CategoryName)
           
                // console.log(this.$route.params.id + form.CategoryName)
                this.update({id:this.$route.params.id,formData});
            }
        },
        
        async fetchCategoryDetails(id) {
            var response =  await  CategoryService.findById(id);
            this.mapFormData(response.data);
        },
        mapFormData(data) {
            this.formData = {
                CategoryName: data.categoryName || '',
                Active: data.active?'1':'0' || '',
                
            };
        }
    },
    computed: {
        ...mapState('category',[
        'success'
      ]),
    },
    watch: {
        'success':  function() {
          if(this.success==true){
            const {showSuccess, showError} = useNotification();
            showSuccess();
            this.$router.push({name:'category'})
          }
        }
       
    },
    mounted() {
        const id = this.$route.params.id;
        this.fetchCategoryDetails(id);
    },
}
</script>

<style scoped></style>