<template>
    <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
        <thead>
            <tr>
                <th data-ordering="false">
                    Srno
                </th>
                <th data-ordering="false">
                    Product Name
                </th>
                <th data-ordering="false">
                    Price
                </th>

                <th data-ordering="false">
                    Category
                </th>
                <th data-ordering="false">
                    Image
                </th>

                <th> Action</th>
            </tr>

        </thead>
        <tbody>

            <tr v-for="(item, key) in data" :key="item.id">

                <td>{{ key + 1 }}</td>
                <td>

                    {{ item.productName }}
                </td>

                <td>{{ item.price }}</td>

                <td>
                    {{ item.category.categoryName }}
                </td>

                <td>
                    <img :src="imageUrls[item.id]" width="100px" alt="Product image" />
                </td>

                <td>
                    <div class="dropdown d-inline-block">
                        <button class="btn btn-soft-secondary btn-sm dropdown" @click="toggleDropdown(key)">
                            <i class="ri-more-fill align-middle"></i>
                        </button>
                        <ul :ref="'dropdownMenu' + key" class="dropdown-menu dropdown-menu-end"
                            style="position: absolute; inset: auto 0px 0px auto; margin: 10px;">
                            <li>
                                <router-link :to="{ name: 'updateproduct', params: { id: item.id } }"
                                    class="dropdown-item edit-item-btn"><i
                                        class="ri-pencil-fill align-bottom me-2 text-muted"></i> Edit</router-link>
                            </li>
                            <li>
                                <a class="dropdown-item remove-item-btn" style="cursor: pointer;"
                                    @click="confirmDelete(item.id)"> <i
                                        class="ri-delete-bin-fill align-bottom me-2 text-muted"></i> Delete</a>
                            </li>
                        </ul>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <pagination></pagination>



</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import Swal from 'sweetalert2';
import { useNotification } from '@/components/admin/notification/Notification.js';
import Pagination from '@/components/admin/pagination/PaginationProduct.vue'
import { AccountService } from "@/service/accountService";
export default {
    name: 'Form Table',
   
    data() {
        return {
            activeDropdownIndex: null,
            account: 'product',
            imageUrls: {},
        }
    },
   
    computed: {
        ...mapGetters('product', ['data', 'loading', 'error']),

    },
    components: {
        Pagination
    },
    methods: {
        ...mapActions('product', ['delete']),

        toggleDropdown(index) {
            // Check if the previously active dropdown is available and remove 'show' class
            if (this.activeDropdownIndex !== null && this.$refs['dropdownMenu' + this.activeDropdownIndex]) {
                const prevDropdown = this.$refs['dropdownMenu' + this.activeDropdownIndex];
                if (prevDropdown.length > 0) {
                    prevDropdown[0].classList.remove('show');
                }
            }

            // Toggle dropdown based on current index
            if (this.activeDropdownIndex === index) {
                this.activeDropdownIndex = null; // Close the dropdown if it's already open
            } else {
                this.activeDropdownIndex = index;
                if (this.$refs['dropdownMenu' + index] && this.$refs['dropdownMenu' + index].length > 0) {
                    this.$refs['dropdownMenu' + index][0].classList.add('show');
                }
            }
        },
        async confirmDelete(id) {
            const result = await Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            });

            if (result.isConfirmed) {
                // Perform the delete operation
                this.deleteItem(id);
            }
        },
        deleteItem(id) {
            // Your delete logic here, e.g., API call to delete the item
            this.delete(id);
        },
        async fetchImage() {
            try {
                for (const element of this.data) {
                        // Assuming `element` has an `id` and that `fetchImage` returns the image URL
                        const imageUrl = await AccountService.fetchImage(element.image);
          
                        this.imageUrls[element.id] = imageUrl; // Set the product ID as the key and image URL as the value
                        // this.$set(this.imageUrls, element.id, imageUrl); // Ensure reactivity
                    }
           
            } catch (error) {
                console.error("Error fetching album:", error);
            }
        }
    },
    watch: {
        'data': 'fetchImage',
        'success': function () {
            if (this.success) {
                Swal.fire(
                    'Deleted!',
                    'Your item has been deleted.',
                    'success'
                );

            }
        }
    },
    async mounted() {
    //    await this.fetchImage();
    },


}
</script>

<style scoped>

</style>