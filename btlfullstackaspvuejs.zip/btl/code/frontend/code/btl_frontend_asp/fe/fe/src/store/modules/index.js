import settings from './settings'
import account from './account'
import category from './category'
import attribute from './attribute'
import attributeoption from './attributeoption'
import product from './product'
import auth from './auth'

export default { settings , account, category,attribute,attributeoption,product, auth}