<template>

    <form method="post" @submit.prevent="submitForm">
        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">Main infor</h4>

                    </div><!-- end card header -->
                    <div class="card-body">

                        <div>
                            <label asp-for="CategoryName" class="form-label ">
                                Name<span style="color:red">(*)</span>
                            </label>
                            <div class="form-icon right">
                                <input type="text" class="form-control form-control-icon" id="CategoryName"
                                    v-model="formData.CategoryName" value="" placeholder="">
                                <i class="ri-account-circle-line"></i>
                            </div>
                            <span @v-if="errors.name" class="text-danger">{{ errors.name }}</span>
                        </div>
                        <div class="col-12" style="padding-left: 0px;">
                            <label asp-for="Active" class="form-label mt-1">
                                Active<span style="color:red">(*)</span>
                            </label>
                            <select v-model="formData.Active" id="Active" class="form-select mb-3"
                                aria-label="Default select example">
                                <option value="">Select your status</option>
                               <option value="1">Active</option>
                               <option value="0">InActive</option> 
                            </select>
                            <span v-if="errors.active" class="text-danger">{{ errors.active }}</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <div class="row mb-3">
            <div class="col-12 text-right">
                <button type="submit" class="btn rounded-pill btn-primary waves-effect waves-light">Submit</button>
            </div>
        </div>
    </form>

</template>

<script>
import {mapActions, mapState} from 'vuex'
import {useNotification} from '@/components/admin/notification/Notification.js'

export default {
    name: 'Form create',
    data() {
        return {
            errors:{},
            file:null,
            formData: {
                'CategoryName': '',
                'Active': ''
            }
        }
    },
    methods: {
        ...mapActions('category', ['create']),
      
        validate() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.CategoryName) {
                this.errors.name = 'Name is required';
                isValid = false;
            }

           
             if (!this.formData.Active){
                this.errors.active = 'Active is required';
                isValid = false;
            }

            return isValid;
        },
        async submitForm() {
            if(this.validate()){
                
                this.create(this.formData);
            }
        },
    },
    computed: {
        ...mapState('category',[
        'success'
      ])
    },
    watch: {
        'success':  function() {
            const {showSuccess, showError} = useNotification();
          if(this.success==true){
            showSuccess();
            this.$router.push({name:'category'})   
          }
        }
    },
}
</script>

<style scoped></style>