<template>
    <div class="body-wrapper">
        <page-header></page-header>
        <slot></slot>
        <page-footer></page-footer>
    </div>

</template>
<script>
import PageFooter from './footer/PageFooter.vue'
import PageHeader from './header/PageHeader.vue';
//css
import '@/assets/css/material-design-iconic-font.min.css';
import '@/assets/css/material-design-iconic-font.min.css';
import '@/assets/css/font-awesome.min.css';
import '@/assets/css/fontawesome-stars.css'
import '@/assets/css/meanmenu.css'
import '@/assets/css/owl.carousel.min.css'
import '@/assets/css/slick.css'
import '@/assets/css/animate.css'
import '@/assets/css/jquery-ui.min.css'
import '@/assets/css/jquery-ui.min.css'
import '@/assets/css/venobox.css'
import '@/assets/css/nice-select.css'
import '@/assets/css/magnific-popup.css'
import '@/assets/css/bootstrap.min.css'
import '@/assets/css/helper.css'
import '@/assets/css/responsive.css'
import '@/assets/css/style.css'
import '@/assets/css/custom.css'

//js
import '@/assets/js/vendor/jquery-1.12.4.min.js';
//  import '@/assets/js/vendor/popper.min.js'; 
//  import '@/assets/js/bootstrap.min.js'; 
import '@/assets/js/ajax-mail.js';
import '@/assets/js/jquery.meanmenu.min.js';
//  import '@/assets/js/wow.min.js';
import '@/assets/js/slick.min.js';
import '@/assets/js/owl.carousel.min.js';
import '@/assets/js/jquery.magnific-popup.min.js';
import '@/assets/js/isotope.pkgd.min.js';
import '@/assets/js/imagesloaded.pkgd.min.js';
import '@/assets/js/jquery.mixitup.min.js';
import '@/assets/js/jquery.countdown.min.js';
import '@/assets/js/jquery.counterup.min.js';
//  import '@/assets/js/waypoints.min.js';
//  import '@/assets/js/jquery.barrating.min';
import '@/assets/js/jquery-ui.min.js';
import '@/assets/js/venobox.min.js';
import '@/assets/js/jquery.nice-select.min.js';
import '@/assets/js/scrollUp.min.js';
//  import '@/assets/js/main.js';

export default {
    name: 'UserLayout',
    components: {
        PageFooter,
        PageHeader
    },
    // computed: {
    //     ...mapState('setting', ['footerLinks', 'copyright']),
    // },
}
</script>

<style scoped></style>