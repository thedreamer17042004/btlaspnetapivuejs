<template>
    <nav>
        <ul>
            <li class="dropdown-holder"><router-link to="/">Home</router-link></li>
            <li class="megamenu-holder"><router-link to="/shop">Shop</router-link></li>
            <li><router-link to="/about">About us</router-link></li>
            <li><router-link to="/contact">Contact us</router-link></li>
            <li><router-link to="/admin">Admin</router-link></li>
            <li><router-link to="/logina">Login admin</router-link></li>
        </ul>
    </nav>
</template>

<script>
export default {
    name: 'MenuWeb'
}
</script>

<style scoped></style>