<template>

    <div class="d-flex justify-content-end mt-3">
        <div class="pagination-wrap hstack gap-2">

            <a class="page-item pagination-prev disabled" @click="prevPage" :disabled="pageNumber === 1">Prev</a>

            <ul class="pagination listjs-pagination mb-0">
                <li style="cursor: pointer;width: 13px;" v-for="page in pages" :key="page"
                    @click="goToPage(page)" :class="{ active: pageNumber == page }">{{ page }}</li>

            </ul>
            <a class="page-item pagination-next" @click="nextPage" :disabled="pageNumber === totalPages">Next</a>

        </div>
    </div>
</template>

<script>
import { mapActions, mapGetters, useStore } from 'vuex'

export default {
    data() {
        return {
            // total: this.pagination.total,
            // pageNumber: this.pagination.pageNumber,
            // pageSize: this.pagination.pageSize
        }
    },
    setup() {
        // const length =Math.ceil(this.totalPages / this.pageSize);
        // return {length}
    },
    methods: {
        ...mapActions('attributeoption', ['fetchData', 'updatePageNumber']),
        prevPage() {
            if (this.pagination.pageNumber > 1) {
                this.pageNumber--;
                this.fetchPageData();
            }
        },
        // Go to the next page
        nextPage() {
            if (this.pagination.pageNumber < this.length) {
                this.pageNumber++;
                this.fetchPageData();
            }
        },
       
        goToPage(page) {
            console.log(this.pageNumber + ' go to page')
            this.pageNumber = page;
            this.fetchPageData();
        },
        fetchPageData() {
            const paginate = {
                pageNumber: this.pageNumber,
                pageSize: 10
            }
            this.fetchData(paginate);
        },

    },
    computed: {
        ...mapGetters('attributeoption', ['pagination']),
        totalPages() {
            return this.pagination.total;
        },
        pageNumber: {
            get() {
                return this.pagination.pageNumber;
            },
            set(value) {
                this.updatePageNumber(value);
            }
        },
        pageSize() {
            return this.pagination.pageSize;
        },
        pages() {
            return Array.from({ length:  Math.ceil(this.totalPages / this.pageSize) }, (_, i) => i + 1);
        },
        length() {
            return Math.ceil(this.totalPages / this.pageSize);
        }

    },
    components: {

    },
    mounted() {
        //  this.fetchPageData(); // Initial fetch when the component is mounted
    },
}
</script>

<style scoped>
.active {
    color: red;
    font-size: 13px;
}
</style>