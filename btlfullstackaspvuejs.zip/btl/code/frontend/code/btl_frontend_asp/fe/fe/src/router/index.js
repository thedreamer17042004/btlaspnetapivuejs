import { createWebHashHistory, createRouter } from 'vue-router'
import {getUserRole} from '@/utils/jwtUtils'

import Home from '@/pages/client/Home.vue'
import About from '@/pages/client/About.vue'
import Shop from '@/pages/client/Shop.vue'
import Contact from '@/pages/client/Contact.vue'
import ProductDetail from '@/pages/client/ProductDetail.vue'
import Checkout from '@/pages/client/Checkout.vue'
import ShoppingCart from '@/pages/client/ShoppingCart.vue'
import Login from '@/pages/client/Login.vue'
import Register from '@/pages/client/Register.vue'
import AdminLayout from '@/layouts/admin/AdminLayout.vue'
import Dashboard from '@/pages/admin/dashboard/Dashboard.vue'
import Account from '@/pages/admin/account/Index.vue'
import AccountCreate from '@/pages/admin/account/Create.vue'
import AccountUpdate from '@/pages/admin/account/Edit.vue'
import Category from '@/pages/admin/category/Index.vue'
import CategoryCreate from '@/pages/admin/category/Create.vue'
import CategoryUpdate from '@/pages/admin/category/Edit.vue'

import Attribute from '@/pages/admin/attribute/Index.vue'
import AttributeCreate from '@/pages/admin/attribute/Create.vue'
import AttributeUpdate from '@/pages/admin/attribute/Edit.vue'

import AttributeOption from '@/pages/admin/attributeOption/Index.vue'
import AttributeOptionUpdate from '@/pages/admin/attributeOption/Edit.vue'
import AttributeOptionCreate from '@/pages/admin/attributeOption/Create.vue'

import Product from '@/pages/admin/product/Index.vue'
import ProductEdit from '@/pages/admin/product/Edit.vue'
import ProductCreate from '@/pages/admin/product/Create.vue'
import Login1 from '@/pages/admin/auth/Login.vue'
import Forbidden from '@/components/admin/error/Forbidden.vue'

import auth from '@/store/modules/auth'

const routes = [
  //client
  {
     path: '/', 
     component: Home , name: "home"
  },
  { path: '/about', component: About, name:"about" },
  { path: '/contact', component: Contact , name:"contact"},
  { path: '/shop', component: Shop , name:"shop"},
  {path:'/product-detail/:id', component: ProductDetail, name:"product-detail"},
  {path:'/checkout', component: Checkout, name: 'checkout'},
  {path:'/cart', component: ShoppingCart, name: 'shopping-cart'},
  {path:'/login', component: Login, name:'login'},
  {path:'/register', component: Register, name:'register'},

  {path:'/logina', component: Login1, name:'loginadmin'},
  //admin
  {
    path: "/admin",
    name: "Admin Home",
    meta: { requiresAuth: true }, 
    component: AdminLayout,
    children: [
      {
        path: '',
        name: "Dashboard",
        meta: {
          icon: "dashboard",
          requiresRole: ['Admin', 'Manager']
        },
        component: Dashboard,
      },
      {
        path: 'account',
        name: "account",
        meta: {
          icon: "account",
          requiresRole: ['Admin']
        },
        component: Account,
      },
      {
        path: 'account/create',
        name: "createaccount",
        meta: {
          icon: "create",
          requiresRole: ['Admin']
        },
        component: AccountCreate,
      },
      {
        path: 'account/edit/:id',
        name: "editaccount",
        meta: {
          icon: "edit",
          requiresRole: ['Admin']
        },
        component: AccountUpdate,
      },
      {
        path:'category',
        name:'category',
        meta: {
          icon: 'category',
          requiresRole: ['Admin']
        },
        component: Category,
      },
      {
        path:'category',
        name:'createcategory',
        meta: {
          icon: 'category',
          requiresRole: ['Admin']
        },
        component: CategoryCreate,
      },
      {
        path:'category/:id',
        name:'updatecategory',
        meta: {
          icon: 'category',
          requiresRole: ['Admin']
        },
        component: CategoryUpdate,
      },

      {
        path:'attribute',
        name:'attribute',
        meta: {
          icon: 'attribute',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: Attribute,
      },
      {
        path:'attribute',
        name:'createattribute',
        meta: {
          icon: 'attribute',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: AttributeCreate,
      },
      {
        path:'attribute/:id',
        name:'updateattribute',
        meta: {
          icon: 'attribute',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: AttributeUpdate,
      },
      
      {
        path:'attributeoption',
        name:'attributeoption',
        meta: {
          icon: 'attributeoption',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: AttributeOption,
      },
      {
        path:'attributeoption',
        name:'createattributeoption',
        meta: {
          icon: 'attributeoption',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: AttributeOptionCreate,
      },
      {
        path:'attributeoption/:id',
        name:'updateattributeoption',
        meta: {
          icon: 'attributeoption',
          requiresRole: ['Admin', 'Manager'] 
        },
        component: AttributeOptionUpdate,
      },

      //product
      {
        path:'product',
        name:'product',
        meta: {
          icon: 'product',
          requiresRole: ['Admin']
        },
        component: Product,
      },
      {
        path:'product',
        name:'createproduct',
        meta: {
          icon: 'product',
          requiresRole: ['Admin']
          
        },
        component: ProductCreate,
      },
      {
        path:'product/:id',
        name:'updateproduct',
        meta: {
          icon: 'product',
          requiresRole: ['Admin']
        },
        component: ProductEdit,
      },
    ]
  },
  { path: '/forbidden', name: 'forbidden', component: Forbidden }, // 403 page
  { path: '/:pathMatch(.*)*', redirect: '/forbidden' } // Redirect all undefined routes
]


const router = createRouter({
  history: createWebHashHistory(), // Use Hash History
  routes,
  strict:true
})


// router.beforeEach((to, from, next) => {
//   if (to.path.startsWith('/admin')) {
//     // Check if the user is authenticated
//     if (auth.state.data!=null) {
//       if(getUserRole(auth.state.data)=='Admin'|| getUserRole(auth.state.data)=='Manager'){
//         next(); // User is authenticated, allow access
//       }else {
//         alert('vào forbidden')
//         next({ name: 'forbidden' }); // Redirect to login if not authenticated
//       }
//     } else {
//       next({ name: 'loginadmin' }); // Redirect to login if not authenticated
//     }
//   } else {
//     next(); // Always allow access if not an admin route
//   }
// });


router.beforeEach(async (to, from, next) => {
  const isAuthenticated = auth.state.data;
  const userRole =  getUserRole(auth.state.data);

  if (to.meta.requiresAuth) {
    if (!isAuthenticated) {
      return next({ name: 'loginadmin' });
    } else if (to.meta.requiresRole && !to.meta.requiresRole.includes(userRole)) {
      console.log(userRole)
      return next({ name: 'forbidden' });
    }
  }

  next();
});

export default router;
