import modules from './modules'
import { createStore } from 'vuex'

// Create a new store instance.
const store = createStore({
  modules
})

export default store;