﻿using AspnetApi.Common;
using AspnetApi.Data;
using AspnetApi.Dtos.Product.Request;
using AspnetApi.Models;
using JwtToken.Dtos;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AspnetApi.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ApiDbContext _context;

        private readonly ICommonService<Product> _commonService;

        private readonly UserManager<Account> _userManager;

        public ProductController(ApiDbContext dbContext, ICommonService<Product> commonService, UserManager<Account> userManager)
        {
            _context = dbContext;
            _commonService = commonService;
            _userManager = userManager;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("search")]
        public async Task<IActionResult> Get([FromBody] QueryParams queryParams)
        {
            var query = _context.Products.AsQueryable();

            var includeFunc = new Func<IQueryable<Product>, IQueryable<Product>>(query =>
               query.Include(p => p.Category)
           );

            var pagedResponse = await _commonService.GetPagedDataAsync(queryParams, new[] { "ProductName" }, includeFunc);

            return Ok(pagedResponse);
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            Product? item = await _context.Products.FirstOrDefaultAsync(t => t.Id==id);

            if (item == null)
            {
                return new JsonResult("Product id Not found") { StatusCode = 400 };
            }

            return Ok(item);

        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Add([FromForm] CreateProductDTO prod)
        {
            var checkExist = await _context.Products.FirstOrDefaultAsync(ct => ct.ProductName.Equals(prod.ProductName));
          
            if (checkExist != null)
            {
                return new JsonResult("Product name is existed") { StatusCode = 400 };
            }

            //upload image
            string json = "";
            var imageProduct = await _commonService.UploadFile(prod.Image);
            if (prod.Album != null)
            {
                List<string> images = await _commonService.UploadFiles(prod.Album);
                json = JsonSerializer.Serialize(images);
            }

            if (!prod.Equals(null))
            {
                Product item = new Product()
                {
                    Price = prod.Price,
                    ProductName = prod.ProductName,
                    SalePrice = prod.SalePrice,
                    Category = await _context.Categories.FindAsync(prod.CategoryId),
                    Description = prod.Description,
                    Active = (prod.Active!=null)? (prod.Active.Equals("1") ? true : false):false,
                    Image = imageProduct,
                    Slug = SlugHelper.GenerateSlug(prod.ProductName),
                    //later
                    Album = json
                };

                await _context.Products.AddAsync(item);
                await _context.SaveChangesAsync();

                //xử lý mảng lên [{attributeId:, optionId}]
                //xử lý tạo list<dto> {productId:1, optionId: }
                List<object> list = JsonSerializer.Deserialize<List<object>>(prod.Attributes);
                List <AttributeOptionProduct> attributes = new List<AttributeOptionProduct>();
                if (prod.Attributes != null)
                {
                    List<AttributeOptionDto> myClassList = ConvertToClassList<AttributeOptionDto>(list);
                    foreach (var attr in myClassList)
                    {

                        AttributeOptionProduct at = new AttributeOptionProduct();
                        at.ProductId = item.Id;
                        at.AttributeOptionId = int.Parse(attr.OptionId);
                        attributes.Add(at);
                    }

                    _context.AttributeOptionProducts.AddRange(attributes);
                    _context.SaveChanges();

                }

                    return CreatedAtAction("GetById", new { item.Id }, prod);
            }

            return new JsonResult("Something went wrong") { StatusCode = 500 };
        }
        static List<T> ConvertToClassList<T>(List<object> objectList)
        {
            var json = JsonSerializer.Serialize(objectList);
            return JsonSerializer.Deserialize<List<T>>(json);
        }
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] UpdateProductDTO prod)
        {
            Product? exist = await _context.Products.FirstOrDefaultAsync(t => t.Id == id);


            if (exist == null)
            {
                throw new ArgumentException($"Product with ID: {id} not found");
            }
            exist.Album = null;
            _context.SaveChanges();

            var imageProduct = await _commonService.UploadFile(prod.Image);

            List<string> oldImagge = JsonSerializer.Deserialize<List<string>>(prod.OldImage);
            string json = "";
            if (prod.Album != null)
            {
                List<string> images = await _commonService.UploadFiles(prod.Album);
                if (oldImagge.Count() > 0)
                {
                    oldImagge.AddRange(images);
                    json = JsonSerializer.Serialize(oldImagge);
                }else
                {
                    json = JsonSerializer.Serialize(images);
                }
            }else
            {
                json = JsonSerializer.Serialize(oldImagge);

            }
          
            if (ModelState.IsValid)
            {
                exist.ProductName = prod.ProductName;
                exist.Price = prod.Price;
                exist.SalePrice = prod.SalePrice;
                exist.Category = await _context.Categories.FindAsync(prod.CategoryId);
                exist.Description = prod.Description;
                exist.Active = (prod.Active != null) ? (prod.Active.Equals("1") ? true : false) : false;
                exist.Slug = SlugHelper.GenerateSlug(prod.ProductName);

                if (imageProduct != null && imageProduct.Length > 0)
                {
                    exist.Image = imageProduct;
                }
                if (json.Length > 0)
                {
                    exist.Album = json;
                }
                await _context.SaveChangesAsync();
                return Ok(exist);
            }

            return new JsonResult("Something went wrong") { StatusCode = 500 };
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            Product? exist = await _context.Products.FirstOrDefaultAsync(t => t.Id == id);

            if (exist.Equals(null)) throw new ArgumentException($"Product with ID: {id} not found");

            if (ModelState.IsValid)
            {
                _context.Remove(exist);
                await _context.SaveChangesAsync();

                return Ok(exist);
            }
            return new JsonResult("Something went wrong") { StatusCode = 500 };

        }

    }
}
