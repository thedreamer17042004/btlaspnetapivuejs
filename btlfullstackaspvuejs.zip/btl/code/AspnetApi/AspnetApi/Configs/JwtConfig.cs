﻿namespace AspnetApi.Config
{
    public class JwtConfig
    {
        public string? Secret { get; set; }
    }
}
