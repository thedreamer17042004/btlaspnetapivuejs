﻿namespace AspnetApi.Constants
{
    public class Constants
    {
        public const string ROOT_IMAGE = "wwwroot/images";
    }
}
