﻿namespace AspnetApi.Dtos.Auth.Response
{
    public class RegisterResponseDTO:AuthResult
    {
    }
}
