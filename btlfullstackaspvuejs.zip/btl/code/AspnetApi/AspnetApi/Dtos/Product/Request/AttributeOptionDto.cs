﻿namespace AspnetApi.Dtos.Product.Request
{
    public class AttributeOptionDto
    {
        public string OptionId { get; set; }
        public string AttributeId {  get; set; }
    }
}
