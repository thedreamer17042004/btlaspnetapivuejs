using AspnetApi.Common;
using AspnetApi.Config;
using AspnetApi.Configs;
using AspnetApi.Data;
using AspnetApi.Models;
using AspnetApi.Services.Auth;
using AspnetApi.Services.User;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

//add Controller 
builder.Services.AddControllers();

//add dbcontext
builder.Services.AddDbContext<ApiDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("AppContext")));

//add cors
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder =>
        {
            builder.WithOrigins("http://localhost:5173")
                   .AllowAnyHeader()
                   .AllowAnyMethod();
        });
});


// Add services to the authentication
Byte[]? key = Encoding.ASCII.GetBytes(builder.Configuration["JwtConfig:Secret"]);
TokenValidationParameters? tokenValidationParams = new TokenValidationParameters
{
    ValidateIssuerSigningKey = true,
    IssuerSigningKey = new SymmetricSecurityKey(key),
    ValidateIssuer = false,
    ValidateAudience = false,
    ValidateLifetime = true,
    RequireExpirationTime = false
};


builder.Services.Configure<JwtConfig>(builder.Configuration.GetSection("JwtConfig"));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(jwt =>
{

    jwt.SaveToken = true;
    jwt.TokenValidationParameters = tokenValidationParams;
});


//add  identity account and identityRole
builder.Services.AddIdentity<Account, IdentityRole>(options =>
{
    options.SignIn.RequireConfirmedAccount = true;
}).
    AddEntityFrameworkStores<ApiDbContext>()
   .AddDefaultTokenProviders();


// Register DI
builder.Services.AddSingleton(tokenValidationParams);
builder.Services.AddScoped<IJwtService, JwtService>();
builder.Services.AddScoped<UserCService>();
builder.Services.AddScoped<IdentitySeeder>();
builder.Services.AddScoped(typeof(ICommonService<>), typeof(CommonService<>));


//add mapper
var mapper = MapConfig.InitializeAutomapper();
builder.Services.AddSingleton(mapper);
var mapperConfig = new MapperConfiguration(mc =>
{
    mc.AddProfile(new MappingProfile());
});

IMapper mapper1 = mapperConfig.CreateMapper();
builder.Services.AddSingleton(mapper1);


var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseHttpsRedirection();
app.UseCors("AllowSpecificOrigin");

app.UseAuthentication();
app.UseAuthorization();

/*
using (var scope = app.Services.CreateScope())
{
    var identitySeeder = scope.ServiceProvider.GetRequiredService<IdentitySeeder>();
    await identitySeeder.SeedAsync();
}
*/

app.MapControllers();

app.Run();
