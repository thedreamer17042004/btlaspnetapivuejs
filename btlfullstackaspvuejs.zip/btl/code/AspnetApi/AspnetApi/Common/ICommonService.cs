﻿using JwtToken.Dtos;

namespace AspnetApi.Common
{
    public interface ICommonService<T> where T : class
    {
        Task<PagedResponse<T>> GetPagedDataAsync(QueryParams queryParams, string[] filterBy, Func<IQueryable<T>, IQueryable<T>> includeFunc=null);
        Task<string> UploadFile(IFormFile? uploadFile);
        Task<List<string>> UploadFiles(List<IFormFile> files);

    }
}
