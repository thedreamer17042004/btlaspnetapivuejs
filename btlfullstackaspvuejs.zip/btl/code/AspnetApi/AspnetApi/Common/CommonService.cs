﻿using AspnetApi.Constants;
using AspnetApi.Data;
using JwtToken.Dtos;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Reflection.Metadata;


namespace AspnetApi.Common
{
    public class CommonService<T> : ICommonService<T> where T : class
    {
        private readonly ApiDbContext _context;
        private readonly DbSet<T> _dbSet;

        public CommonService(ApiDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        public async Task<PagedResponse<T>> GetPagedDataAsync(QueryParams queryParams, string[] filterBy, Func<IQueryable<T>, IQueryable<T>> includeFunc = null)
        {
            var query = _dbSet.AsQueryable();

            // Apply filtering
            if (!string.IsNullOrEmpty(queryParams.Keyword))
            {
                query = ApplyFilter(query, filterBy, queryParams.Keyword);
            }

            if (!string.IsNullOrEmpty(queryParams.Status))
            {
                bool status = queryParams.Status.Equals("1");
                query = query.Where(item => EF.Property<bool>(item, "Active") == status);
            }

            // Apply sorting
            if (!string.IsNullOrEmpty(queryParams.SortBy) && !string.IsNullOrEmpty(queryParams.SortDir))
            {
                query = SortHelper.ApplySorting(query, queryParams.SortBy, string.Equals(queryParams.SortDir, "asc", StringComparison.OrdinalIgnoreCase));
            }

            // Get total records
            var totalRecords = await query.CountAsync();

            if (includeFunc != null)
            {
                query = includeFunc(query);
            }

            // Apply pagination
            var items = await query
                .Skip((queryParams.PageNumber - 1) * queryParams.PageSize)
                .Take(queryParams.PageSize)
                .ToListAsync();

            // Create and return paginated response
            return new PagedResponse<T>(items, totalRecords, queryParams.PageNumber, queryParams.PageSize);
        }

        public  async Task<string> UploadFile(IFormFile? uploadFile)
        {
            var uniqueFileName = "";
            if (uploadFile != null && uploadFile.Length > 0)
            {
                uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(uploadFile.FileName);
                var filePath = Path.Combine(Constants.Constants.ROOT_IMAGE, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await uploadFile.CopyToAsync(stream);
                }

            }
            else
            {
                return null;
            }
            return uniqueFileName;
        }

        public async Task<List<string>> UploadFiles(List<IFormFile> files)
        {
            var savedFileNames = new List<string>();

            foreach (var file in files)
            {
                if (file.Length > 0)
                {
                    // Generate a unique file name to avoid collisions
                    var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                    var filePath = Path.Combine(Constants.Constants.ROOT_IMAGE, uniqueFileName);

                    // Save the file
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    savedFileNames.Add(uniqueFileName);
                }
            }

            return savedFileNames;
        }

        private static IQueryable<T> ApplyFilter(IQueryable<T> query, string[] propertyNames, string keyword)
        {
            if (propertyNames.Length <= 0 || string.IsNullOrEmpty(keyword))
            {
                return query;
            }

            var parameter = Expression.Parameter(typeof(T), "item");


            var expressions = new List<Expression>();

            foreach (var propertyName in propertyNames)
            {
                var property = Expression.Property(parameter, propertyName);
                var containsMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });
                var searchValue = Expression.Constant(keyword, typeof(string));
                var propertyExpression = Expression.Call(property, containsMethod, searchValue);

                expressions.Add(propertyExpression);
            }

            // Combine all expressions with OR
            Expression combinedExpression = expressions
            .Aggregate<Expression>((left, right) => Expression.OrElse(left, right));

            var lambda = Expression.Lambda<Func<T, bool>>(combinedExpression, parameter);

            return query.Where(lambda);
        }
    }
}
